let familia = new Set(['Arturo', 'Teresa', 'Gabriela', 'Laura', 'Andrés']);
familia.add('Andrés');
familia.add('Javascript');

console.log(familia);